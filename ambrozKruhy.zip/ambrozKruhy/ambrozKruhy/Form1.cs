﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ambrozKruhy
{
    public partial class Form1 : Form
    {
        List<kruhy> kruhys;
        public Form1()
        {
            InitializeComponent();
            kruhys = new List<kruhy>();
            nmrVelikost.Maximum = 500;
            nmrVelikost.Minimum = 20;
            nmrVelikost.Value = 20;
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            kruhy noveKruhy = new kruhy();
            //Random random = new Random();
            ///noveKruhy.Location = new Point(random.Next(0, pictureBox6.Width), random.Next(0, pictureBox6.Height));
            noveKruhy.Velikost = Convert.ToInt32(nmrVelikost.Value);
            noveKruhy.KruhColor1 = pboxColor1.BackColor;
            noveKruhy.KruhColor2 = pboxColor2.BackColor;
            noveKruhy.KruhColor3 = pboxColor3.BackColor;
            noveKruhy.KruhColor4 = pboxColor4.BackColor;
            noveKruhy.KruhColor5 = pboxColor5.BackColor;
            if (checkBox1.Checked)
            {
                Random r = new Random();
                noveKruhy.Location = new Point(r.Next(0, pictureBox6.Width), r.Next(0, pictureBox6.Height));
            }
            else noveKruhy.Location = new Point((int)XUpDown.Value, (int)YUpDown.Value);
            kruhys.Add(noveKruhy);
            pictureBox6.Refresh();

        }

        private void pictureBox6_Paint(object sender, PaintEventArgs e)
        {
            foreach (var kruhy in kruhys)
            {
                kruhy.Draw(e.Graphics);
            }
        }

        private void pboxColor1_Click(object sender, EventArgs e)
        {
            colorDialog1.Color = pboxColor1.BackColor;
            colorDialog1.ShowDialog();
            pboxColor1.BackColor = colorDialog1.Color;
        }

        private void pboxColor2_Click(object sender, EventArgs e)
        {
            colorDialog1.Color = pboxColor2.BackColor;
            colorDialog1.ShowDialog();
            pboxColor2.BackColor = colorDialog1.Color;
        }

        private void pboxColor3_Click(object sender, EventArgs e)
        {
            colorDialog1.Color = pboxColor3.BackColor;
            colorDialog1.ShowDialog();
            pboxColor3.BackColor = colorDialog1.Color;
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pboxColor4_Click(object sender, EventArgs e)
        {
            colorDialog1.Color = pboxColor4.BackColor;
            colorDialog1.ShowDialog();
            pboxColor4.BackColor = colorDialog1.Color;
        }

        private void pboxColor5_Click(object sender, EventArgs e)
        {
            colorDialog1.Color = pboxColor5.BackColor;
            colorDialog1.ShowDialog();
            pboxColor5.BackColor = colorDialog1.Color;
        }

        private void nmrVelikost_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
