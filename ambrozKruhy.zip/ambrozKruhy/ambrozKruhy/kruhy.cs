﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ambrozKruhy
{
    public class kruhy
    {
        public Point Location { get; set; }
        public int Velikost { get; set; }
        public Color KruhColor1 { get; set; }
        public Color KruhColor2 { get; set; }
        public Color KruhColor3 { get; set; }
        public Color KruhColor4 { get; set; }
        public Color KruhColor5 { get; set; }





        public void Draw(Graphics g)
        {
            Pen pen = new Pen(KruhColor2, Velikost / 20);

            g.DrawEllipse(pen, Location.X, Location.Y, Velikost, Velikost);
            pen.Color = KruhColor1;
            g.DrawEllipse(pen, (int)(Location.X - Velikost * 1.2), Location.Y, Velikost, Velikost);
            pen.Color = KruhColor3;
            g.DrawEllipse(pen, (int)(Location.X + Velikost * 1.2), Location.Y, Velikost, Velikost);
            pen.Color = KruhColor4;
            g.DrawEllipse(pen, (int)(Location.X - Velikost * 0.6), Location.Y + (int)(Velikost * 0.6), Velikost, Velikost);
            pen.Color = KruhColor5;
            g.DrawEllipse(pen, (int)(Location.X + Velikost * 0.6), Location.Y + (int)(Velikost * 0.6), Velikost, Velikost);
        }
    }
}